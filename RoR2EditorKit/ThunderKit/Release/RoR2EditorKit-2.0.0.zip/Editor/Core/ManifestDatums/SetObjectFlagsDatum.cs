using ThunderKit.Core.Manifests;
using UnityEngine;

namespace RoR2EditorKit.Core.ManifestDatums
{
    public class SetObjectFlagsDatum : ManifestDatum
    {
        public Object[] objects;
    }
}
