﻿using RoR2EditorKit.Core.Inspectors;
using RoR2.Skills;
using UnityEditor;

namespace RoR2EditorKit.RoR2Related.Inspectors
{
    [CustomEditor(typeof(SkillFamily))]
    public class SkillFamilyInspector : IMGUIToVisualElementInspector
    {

    }
}