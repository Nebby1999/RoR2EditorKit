﻿using UnityEngine;

//This just locates the state drawer in the project so it can reference the textures
namespace RoR2EditorKit.Common
{
    public class DrawerLocator : ScriptableObject
    {
    }
}