using ThunderKit.Core.Manifests;
using UnityEngine;

namespace RoR2EditorKit.Core.ManifestDatums
{
    public class ReplaceTextInFilesDatum : ManifestDatum
    {
        public Object[] Objects;
    }
}
